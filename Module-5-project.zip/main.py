#Preston Kostyo_Bires
#1.27.22
#Mystery decoder

 #changing the letters
def cat():
  print("supportedletters: ABCDEFGHIJKLMNOPQRSTUVWXYZ".lower())
  #input and input conversion
  userin = input("enter something to encrypt: ").lower()

  userin=userin.replace("a", "@")
  userin=userin.replace("e", "#")
  userin=userin.replace("i", "%")
  userin=userin.replace("o", "*")
  userin=userin.replace("u", "&")
  userin=userin.replace("b", "¥")
  userin=userin.replace("c", ":")
  userin=userin.replace("d", "?")
  userin=userin.replace("f", "§")
  userin=userin.replace("g", "_")
  userin=userin.replace("h", "-")
  userin=userin.replace("i", "^")
  userin=userin.replace("j", "£")
  userin=userin.replace("k", ">")
  userin=userin.replace("l", "<")
  userin=userin.replace("m", "€")
  userin=userin.replace("n", "~")
  userin=userin.replace("p", "!")
  userin=userin.replace("q", "/")
  userin=userin.replace("r", "2")
  userin=userin.replace("s", "5")
  userin=userin.replace("t", "9")
  userin=userin.replace("v", "8")
  userin=userin.replace("w", "4")
  userin=userin.replace("x", "6")
  userin=userin.replace("y", "7")
  userin=userin.replace("z", "=")
                                            
#prints input changed to signs
  print(userin)
cat()


#weird charcters that get changed to letters correpsond with alphabet
print("supportedsignsornumbers: @#%*&¥:?§_-^£><€~!/2598467=")
def coolcat():
  userin = input("now reverse it!: ").lower()

  userin=userin.replace("@", "a")
  userin=userin.replace("#", "e")
  userin=userin.replace("%", "i")
  userin=userin.replace("*", "o")
  userin=userin.replace("&", "u")
  userin=userin.replace("¥", "b")
  userin=userin.replace(":", "c")
  userin=userin.replace("?", "d")
  userin=userin.replace("§", "f")
  userin=userin.replace("_", "g")
  userin=userin.replace("-", "h")
  userin=userin.replace("£", "j")
  userin=userin.replace(">", "k")
  userin=userin.replace("<", "l")
  userin=userin.replace("€", "m")
  userin=userin.replace("~", "n")
  userin=userin.replace("!", "p")
  userin=userin.replace("/", "q")
  userin=userin.replace("2", "r")
  userin=userin.replace("5", "s")
  userin=userin.replace("9", "t")
  userin=userin.replace("8", "v")
  userin=userin.replace("4", "w")
  userin=userin.replace("6", "x")
  userin=userin.replace("7", "y")
  userin=userin.replace("=", "z")
                                            
#prints input changed back to words
  print(userin)
coolcat()
