#Name: Preston K.Bires
#Date: 3/9-3/11/22
#Program: UNIT 8 PROJECT

#THIS IS PART 1(A)
#part D/E
#creates list from user input and checks if it is the correct type
#This program uses a while loop to allow infinte input until the input == -1
my_numbers = []
while True:
  try:
#input
    num = int(input("number 20-200: "))
#if's to check list for error
    if num >= 20 and num <= 200:
      my_numbers.append(num)
    if num > 200:
      print("invalid response")
    if num < 20 and num > 0:
      print("invalid response")
      continue
    if num == -1:
      break 
  except ValueError:
    print("Must be number...")
#part B
#finds rhe minimum of your list and then prints it
def findMinimum(numbers):
#checking the type, returning the min
  if type(numbers) != type([1, 2, 3]):
    print("invalid")
  if type(numbers) == type([1, 2, 3]):
    numbers = min(numbers)
    print("your minimum is: ")
    print("")
    return numbers
#calls function to your list
print(findMinimum(my_numbers))
#part C
#finds the sum of your list and prints it
def findSum(numbers):
#checking the list, returning the sum
  if type(numbers) != type([1, 2, 3]):
    print("invalid")
  if type(numbers) == type([1, 2, 3]):
    Sum = sum(numbers)
    print("your sum is: ")
    print("")
    return Sum
#calls function to your list
print(findSum(my_numbers))

